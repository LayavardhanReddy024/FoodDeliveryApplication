package delivery;

/**
 * 
 */
public class Dish {
    private String restname;
    private String dishname;
    private String description;
    private String price;
    private String vegOrNonveg;
    private String imageurl;
    
	public String getRestname() {
		return restname;
	}
	public void setRestname(String restname) {
		this.restname = restname;
	}
	public String getDishname() {
		return dishname;
	}
	public void setDishname(String dishname) {
		this.dishname = dishname;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getVegOrNonveg() {
		return vegOrNonveg;
	}
	public void setVegOrNonveg(String vegOrNonveg) {
		this.vegOrNonveg = vegOrNonveg;
	}
	public String getImageurl() {
		return imageurl;
	}
	public void setImageurl(String imageurl) {
		this.imageurl = imageurl;
	}

    // Getters and Setters
    // ...
}
